import flet as ft
import asyncio
import json
from datetime import datetime, timedelta
from services.handover_service import handover_service
from services import audio_service
from utils.logger import log_info, log_error, log_debug
from views.styles import AppColors, AppTextStyles, AppLayout, AppButtons
from views.components.app_header import AppHeader


def get_handover_controls(page: ft.Page, navigate_to):
    user_id = page.session.get("user_id")
    channel_id = page.session.get("channel_id")

    # UI State
    current_tab = "인수 인계"
    grouped_data = {}
    POLL_INTERVAL = 10  # Seconds

    # Voice Recording State
    voice_state = {"is_recording": False, "is_listening": False}
    audio_recorder = getattr(page, "audio_recorder", None)
    is_web_mode = getattr(page, "web", True)  # Default to web mode for safety

    # Controls
    list_view = ft.ListView(expand=True, spacing=10, padding=20)
    input_tf = ft.TextField(
        hint_text="내용을 입력하세요...",
        expand=True,
        border_radius=20,
        bgcolor="#F5F5F5",
        border_color="transparent",
        content_padding=ft.padding.symmetric(horizontal=15, vertical=10),
        multiline=True,
        min_lines=1,
        max_lines=4,
    )

    # Voice Recording Status
    voice_status = ft.Text("", size=11, color="red", visible=False)

    # Mic Icon & Button
    mic_icon = ft.Icon(ft.Icons.MIC, color="white", size=20)
    mic_btn = ft.Container(
        content=mic_icon,
        width=40, height=40,
        bgcolor="#00C73C",
        border_radius=20,
        alignment=ft.alignment.center,
        tooltip="음성으로 입력",
        ink=True,
    )

    def update_mic_ui(is_active=False, status_msg=""):
        if is_active:
            mic_icon.name = ft.Icons.STOP
            mic_btn.bgcolor = "red"
            voice_status.value = status_msg or "듣는 중..."
            voice_status.color = "red"
            voice_status.visible = True
        else:
            mic_icon.name = ft.Icons.MIC
            mic_btn.bgcolor = "#00C73C"
            voice_status.visible = False
        try:
            mic_btn.update()
            voice_status.update()
        except Exception:
            pass

    # ============================================
    # Web Speech API (모바일/웹용) - JavaScript 기반
    # iOS Safari 호환성 개선
    # ============================================
    async def start_web_speech():
        """Web Speech API를 사용한 브라우저 내 음성인식 (iOS 호환)"""
        if voice_state["is_listening"]:
            log_debug("[Voice] Already listening, skipping")
            return

        voice_state["is_listening"] = True
        update_mic_ui(True, "🎤 말씀하세요...")
        log_info("[Voice] Starting Web Speech API")

        # iOS Safari 호환 Web Speech API JavaScript
        # - iOS에서는 webkitSpeechRecognition 사용
        # - 에러 처리 강화
        # - 타임아웃 처리 추가
        js_code = """
        (function() {
            // 이전 결과 초기화
            window.speechResult = { status: 'initializing' };

            // iOS/Safari 호환성 체크
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

            if (!SpeechRecognition) {
                window.speechResult = { status: 'error', error: 'not_supported' };
                console.log('[Voice] SpeechRecognition not supported');
                return;
            }

            try {
                const recognition = new SpeechRecognition();
                recognition.lang = 'ko-KR';
                recognition.interimResults = false;
                recognition.maxAlternatives = 1;
                recognition.continuous = false;

                // iOS에서 중요: 짧은 타임아웃 설정
                let timeoutId = setTimeout(() => {
                    console.log('[Voice] Timeout - stopping recognition');
                    try {
                        recognition.stop();
                    } catch(e) {}
                    if (window.speechResult.status === 'listening') {
                        window.speechResult = { status: 'error', error: 'timeout' };
                    }
                }, 10000);  // 10초 타임아웃

                window.speechResult = { status: 'listening' };
                console.log('[Voice] Recognition started, listening...');

                recognition.onresult = (event) => {
                    clearTimeout(timeoutId);
                    console.log('[Voice] Got result');
                    if (event.results && event.results[0] && event.results[0][0]) {
                        const transcript = event.results[0][0].transcript;
                        const confidence = event.results[0][0].confidence;
                        console.log('[Voice] Transcript:', transcript, 'Confidence:', confidence);
                        window.speechResult = { status: 'done', text: transcript, confidence: confidence };
                    } else {
                        window.speechResult = { status: 'done', text: '' };
                    }
                };

                recognition.onerror = (event) => {
                    clearTimeout(timeoutId);
                    console.log('[Voice] Error:', event.error);
                    window.speechResult = { status: 'error', error: event.error || 'unknown' };
                };

                recognition.onend = () => {
                    clearTimeout(timeoutId);
                    console.log('[Voice] Recognition ended, current status:', window.speechResult.status);
                    // 아직 listening 상태면 완료로 변경 (음성 없이 종료된 경우)
                    if (window.speechResult.status === 'listening') {
                        window.speechResult = { status: 'done', text: '' };
                    }
                };

                recognition.onnomatch = () => {
                    clearTimeout(timeoutId);
                    console.log('[Voice] No match');
                    window.speechResult = { status: 'done', text: '' };
                };

                // iOS Safari: 사용자 제스처 컨텍스트 내에서 start() 호출 필수
                recognition.start();
                console.log('[Voice] recognition.start() called');

            } catch(e) {
                console.log('[Voice] Exception:', e.message);
                window.speechResult = { status: 'error', error: e.message || 'start_failed' };
            }
        })();
        """

        try:
            # Start speech recognition
            log_debug("[Voice] Executing JavaScript...")
            await page.run_javascript_async(js_code)
            log_debug("[Voice] JavaScript executed, starting poll...")

            # Poll for result (max 12 seconds, 0.4초 간격)
            max_polls = 30
            for i in range(max_polls):
                await asyncio.sleep(0.4)

                try:
                    result = await page.run_javascript_async("JSON.stringify(window.speechResult || {})")
                    log_debug(f"[Voice] Poll {i+1}/{max_polls}: {result}")
                except Exception as js_err:
                    log_error(f"[Voice] JavaScript poll error: {js_err}")
                    continue

                if not result:
                    continue

                try:
                    data = json.loads(result)
                except json.JSONDecodeError:
                    log_error(f"[Voice] JSON parse error: {result}")
                    continue

                status = data.get("status", "")

                # 아직 초기화/리스닝 중이면 계속 대기
                if status in ["initializing", "listening"]:
                    continue

                # 에러 처리
                if status == "error":
                    error_code = data.get("error", "unknown")
                    log_error(f"[Voice] Speech recognition error: {error_code}")

                    error_messages = {
                        "not_supported": "이 브라우저는 음성인식을 지원하지 않습니다.\niOS 14.5 이상 또는 Chrome을 사용해주세요.",
                        "not-allowed": "마이크 권한을 허용해주세요.\n설정 > Safari > 마이크에서 권한을 확인하세요.",
                        "no-speech": "음성이 감지되지 않았습니다.\n다시 시도해주세요.",
                        "audio-capture": "마이크에 접근할 수 없습니다.\n다른 앱이 마이크를 사용 중인지 확인하세요.",
                        "network": "네트워크 오류입니다. 인터넷 연결을 확인하세요.",
                        "aborted": "음성 인식이 중단되었습니다.",
                        "timeout": "시간이 초과되었습니다. 다시 시도해주세요.",
                        "start_failed": "음성 인식을 시작할 수 없습니다.\nHTTPS 연결이 필요합니다.",
                    }
                    msg = error_messages.get(error_code, f"음성 인식 오류: {error_code}")

                    page.snack_bar = ft.SnackBar(ft.Text(msg), bgcolor="red")
                    page.snack_bar.open = True
                    break

                # 완료 처리
                if status == "done":
                    text = data.get("text", "").strip()
                    log_info(f"[Voice] Recognition done. Text: '{text}'")

                    if text:
                        # 기존 텍스트에 추가
                        if input_tf.value:
                            input_tf.value = input_tf.value + " " + text
                        else:
                            input_tf.value = text
                        input_tf.update()
                        page.snack_bar = ft.SnackBar(
                            ft.Text("✅ 음성이 변환되었습니다."),
                            bgcolor="green"
                        )
                    else:
                        page.snack_bar = ft.SnackBar(
                            ft.Text("음성이 인식되지 않았습니다. 다시 시도해주세요."),
                            bgcolor="orange"
                        )
                    page.snack_bar.open = True
                    break
            else:
                # 폴링 완료 후에도 결과가 없으면
                log_error("[Voice] Polling timeout - no result received")
                page.snack_bar = ft.SnackBar(
                    ft.Text("음성 인식 시간이 초과되었습니다."),
                    bgcolor="orange"
                )
                page.snack_bar.open = True

        except Exception as e:
            log_error(f"[Voice] start_web_speech exception: {e}")
            page.snack_bar = ft.SnackBar(
                ft.Text(f"음성 인식 실패: {str(e)[:50]}"),
                bgcolor="red"
            )
            page.snack_bar.open = True
        finally:
            voice_state["is_listening"] = False
            update_mic_ui(False)
            page.update()
            log_info("[Voice] Web speech session ended")

    # ============================================
    # Desktop AudioRecorder + Whisper API
    # ============================================
    async def start_desktop_recording():
        """데스크톱: AudioRecorder + OpenAI Whisper"""
        if voice_state["is_recording"]:
            log_debug("[Voice] Already recording")
            return
        if not audio_recorder:
            log_error("[Voice] AudioRecorder not available")
            page.snack_bar = ft.SnackBar(
                ft.Text("오디오 녹음기를 사용할 수 없습니다."),
                bgcolor="red"
            )
            page.snack_bar.open = True
            page.update()
            return

        try:
            voice_state["is_recording"] = True
            update_mic_ui(True, "🎤 녹음 중... (클릭하여 중지)")
            log_info("[Voice] Starting desktop recording")

            fname = f"handover_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav"
            await audio_recorder.start_recording_async(output_path=fname)
            log_debug(f"[Voice] Recording started: {fname}")

        except Exception as e:
            log_error(f"[Voice] Recording start failed: {e}")
            voice_state["is_recording"] = False
            update_mic_ui(False)
            page.snack_bar = ft.SnackBar(ft.Text(f"녹음 시작 실패: {e}"), bgcolor="red")
            page.snack_bar.open = True
            page.update()

    async def stop_desktop_recording():
        """데스크톱: 녹음 중지 및 Whisper 변환"""
        if not voice_state["is_recording"]:
            log_debug("[Voice] Not recording, nothing to stop")
            return

        try:
            update_mic_ui(True, "⏳ AI 변환 중...")
            log_info("[Voice] Stopping recording and transcribing")

            res = await audio_recorder.stop_recording_async()
            voice_state["is_recording"] = False
            log_debug(f"[Voice] Recording stopped, result: {res}")

            if res:
                # [FIX] blob URL 감지 - 웹 브라우저에서 발생
                if res.startswith("blob:"):
                    log_info("[Voice] Blob URL detected, switching to Web Speech API")
                    update_mic_ui(False)
                    page.snack_bar = ft.SnackBar(
                        ft.Text("브라우저에서는 Web Speech API를 사용합니다."),
                        bgcolor="orange"
                    )
                    page.snack_bar.open = True
                    page.update()
                    # Web Speech API로 재시도
                    await start_web_speech()
                    return

                text = await asyncio.to_thread(lambda: audio_service.transcribe_audio(res))
                log_info(f"[Voice] Transcription result: '{text[:50] if text else 'empty'}...'")

                if text:
                    if input_tf.value:
                        input_tf.value = input_tf.value + " " + text
                    else:
                        input_tf.value = text
                    input_tf.update()
                    page.snack_bar = ft.SnackBar(
                        ft.Text("✅ 음성이 변환되었습니다."),
                        bgcolor="green"
                    )
                else:
                    page.snack_bar = ft.SnackBar(
                        ft.Text("음성 인식 결과가 없습니다."),
                        bgcolor="orange"
                    )
                page.snack_bar.open = True
            else:
                log_error("[Voice] No recording result")
                page.snack_bar = ft.SnackBar(
                    ft.Text("녹음 결과가 없습니다."),
                    bgcolor="orange"
                )
                page.snack_bar.open = True

            update_mic_ui(False)
            page.update()

        except Exception as e:
            log_error(f"[Voice] Transcription failed: {e}")
            voice_state["is_recording"] = False
            update_mic_ui(False)
            page.snack_bar = ft.SnackBar(ft.Text(f"음성 변환 실패: {e}"), bgcolor="red")
            page.snack_bar.open = True
            page.update()

    # ============================================
    # 마이크 버튼 클릭 핸들러
    # ============================================
    def on_mic_click(e):
        """마이크 버튼 클릭 - iOS 호환성을 위해 즉시 실행"""
        log_info(f"[Voice] Mic clicked. is_listening={voice_state['is_listening']}, is_recording={voice_state['is_recording']}")

        if voice_state["is_listening"]:
            # 이미 리스닝 중이면 무시
            log_debug("[Voice] Already listening, ignoring click")
            return

        if voice_state["is_recording"]:
            # 녹음 중이면 중지
            page.run_task(stop_desktop_recording)
            return

        # 음성 인식 시작
        page.run_task(try_speech_recognition)

    async def try_speech_recognition():
        """Web Speech API를 먼저 시도하고, 실패 시 AudioRecorder 사용"""
        log_info("[Voice] try_speech_recognition called")

        try:
            # iOS Safari 및 모바일 브라우저 감지
            check_js = """
            (function() {
                try {
                    // window 객체 확인
                    if (typeof window === 'undefined') return 'no_window';

                    // iOS 감지
                    var isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
                    var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
                    var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

                    // SpeechRecognition API 확인
                    var hasSpeechAPI = !!(window.SpeechRecognition || window.webkitSpeechRecognition);

                    console.log('[Voice Check] iOS:', isIOS, 'Safari:', isSafari, 'Mobile:', isMobile, 'SpeechAPI:', hasSpeechAPI);

                    if (hasSpeechAPI) {
                        return JSON.stringify({
                            supported: true,
                            isIOS: isIOS,
                            isSafari: isSafari,
                            isMobile: isMobile
                        });
                    }
                    return JSON.stringify({ supported: false });
                } catch(e) {
                    return JSON.stringify({ supported: false, error: e.message });
                }
            })()
            """

            result_str = await page.run_javascript_async(check_js)
            log_debug(f"[Voice] Speech API check result: {result_str}")

            try:
                result = json.loads(result_str) if result_str else {"supported": False}
            except json.JSONDecodeError:
                result = {"supported": result_str == "supported"}

            if result.get("supported"):
                log_info(f"[Voice] Web Speech API supported. iOS={result.get('isIOS')}, Safari={result.get('isSafari')}")
                await start_web_speech()
            else:
                log_info("[Voice] Web Speech API not supported, trying AudioRecorder")
                if audio_recorder:
                    await start_desktop_recording()
                else:
                    page.snack_bar = ft.SnackBar(
                        ft.Text("이 기기에서는 음성 인식을 사용할 수 없습니다."),
                        bgcolor="orange"
                    )
                    page.snack_bar.open = True
                    page.update()

        except Exception as e:
            log_error(f"[Voice] try_speech_recognition error: {e}")
            # Web Speech 실패 시 AudioRecorder 시도
            if audio_recorder and not voice_state["is_recording"]:
                log_info("[Voice] Falling back to AudioRecorder")
                await start_desktop_recording()
            else:
                page.snack_bar = ft.SnackBar(
                    ft.Text("음성 인식을 시작할 수 없습니다."),
                    bgcolor="red"
                )
                page.snack_bar.open = True
                page.update()

    mic_btn.on_click = on_mic_click

    # ============================================
    # 기존 기능들
    # ============================================
    def open_edit_dialog(item):
        edit_tf = ft.TextField(value=item.get("content", ""), multiline=True, expand=True)

        async def save_edit(e):
            print(f"[VIEW DEBUG] save_edit clicked. Item ID: {item.get('id')}, User ID: {user_id}")
            try:
                if await handover_service.update_handover(item.get("id"), edit_tf.value, user_id):
                    print("[VIEW DEBUG] Update success")
                    page.close(dlg)
                    await fetch_and_update()
                else:
                    print("[VIEW DEBUG] Update returned False")
                    page.open(ft.SnackBar(ft.Text("수정 실패: 권한이 없거나 오류 발생"), bgcolor="red"))
                    page.update()
            except Exception as ex:
                print(f"[VIEW DEBUG] Update Exception: {ex}")
                page.open(ft.SnackBar(ft.Text(f"오류: {ex}"), bgcolor="red"))
                page.update()

        dlg = ft.AlertDialog(
            title=ft.Text("기록 수정"),
            content=ft.Container(content=edit_tf, height=100),
            actions=[
                ft.TextButton("취소", on_click=lambda _: page.close(dlg)),
                ft.ElevatedButton("저장", on_click=save_edit, style=AppButtons.PRIMARY())
            ]
        )
        page.open(dlg)

    async def delete_entry(item_id):
        await handover_service.delete_handover(item_id, user_id)
        await fetch_and_update()

    def render_feed():
        list_view.controls.clear()
        target_cat = "handover" if current_tab == "인수 인계" else "order"

        # Sort dates ascending (oldest first, latest at bottom)
        sorted_dates = sorted(grouped_data.keys(), reverse=False)

        for d_str in sorted_dates:
            items = grouped_data[d_str].get(target_cat, [])
            if not items: continue

            # Date Header
            dt = datetime.fromisoformat(d_str)
            m, d = dt.month, dt.day
            today_str = (datetime.utcnow() + timedelta(hours=9)).strftime("%Y-%m-%d")
            header_text = f"{m}월 {d}일"
            if d_str == today_str: header_text += " (오늘)"

            list_view.controls.append(
                ft.Container(
                    content=ft.Text(header_text, size=12, color="grey", weight="bold"),
                    alignment=ft.alignment.center,
                    padding=ft.padding.only(top=10, bottom=5)
                )
            )

            for item in items:
                content = item.get("content", "")
                time_str = item.get("time_str", "")
                author = item.get("user_name", "")
                item_id = item.get("id")

                def create_edit_handler(i):
                    async def handler(e): open_edit_dialog(i)
                    return handler

                def create_delete_handler(oid):
                    async def handler(e): await delete_entry(oid)
                    return handler

                edit_btn = ft.IconButton(ft.Icons.EDIT, icon_size=16, icon_color="grey", on_click=create_edit_handler(item))
                delete_btn = ft.IconButton(ft.Icons.CLOSE, icon_size=16, icon_color="grey", on_click=create_delete_handler(item_id))

                card = ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text(content, size=15, color="#424242", expand=True),
                            ft.Row([edit_btn, delete_btn], spacing=0)
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, vertical_alignment=ft.CrossAxisAlignment.START),
                        ft.Row([
                            ft.Text(f"{author}", size=10, color="grey"),
                            ft.Text(time_str, size=10, color="grey")
                        ], alignment=ft.MainAxisAlignment.END)
                    ], spacing=5),
                    padding=10, bgcolor="white", border_radius=12, border=ft.border.all(1, "#EEEEEE"),
                )
                list_view.controls.append(card)

        list_view.controls.append(ft.Container(height=20))
        page.update()
        # [FIX] Scroll to bottom aka "Latest"
        try:
            list_view.scroll_to(offset=-1, duration=300)
            page.update()
        except Exception:
            pass

    async def fetch_and_update():
        raw = await handover_service.get_handovers(channel_id)
        from collections import defaultdict
        temp_grouped = defaultdict(lambda: {"handover": [], "order": []})
        raw.sort(key=lambda x: x.get("created_at") or "")
        for item in raw:
            try:
                c_at = item.get("created_at")
                if c_at:
                    if c_at.endswith('Z'): c_at = c_at.replace('Z', '+00:00')
                    dt = datetime.fromisoformat(c_at) + timedelta(hours=9)
                    d_key = dt.strftime("%Y-%m-%d")
                    t_str = dt.strftime("%H:%M")
                    cat = item.get("category", "handover")
                    profile = item.get("profiles")
                    user_name = profile.get("full_name") if profile else "멤버"
                    temp_grouped[d_key][cat].append({"id": item.get("id"), "content": item.get("content"), "time_str": t_str, "user_name": user_name})
            except (ValueError, KeyError, AttributeError):
                pass  # Invalid date or missing data
        nonlocal grouped_data
        grouped_data = dict(temp_grouped)
        render_feed()

    async def submit_entry(e=None):
        txt = input_tf.value
        if not txt.strip(): return
        input_tf.value = ""; input_tf.update()
        target_cat = "handover" if current_tab == "인수 인계" else "order"
        await handover_service.add_handover_entry(user_id, channel_id, target_cat, txt)
        await fetch_and_update()

    def on_tab_change(e):
        nonlocal current_tab
        # e.control.data holds the tab name
        current_tab = e.control.data 
        
        # Update UI of tabs
        for c in tabs_row.controls:
            # Only update containers that are tabs (have data)
            if isinstance(c, ft.Container) and c.data:
                is_selected = c.data == current_tab
                # Update text style
                if isinstance(c.content, ft.Text):
                    c.content.color = "#1565C0" if is_selected else "#9E9E9E"
                    c.content.weight = ft.FontWeight.BOLD if is_selected else ft.FontWeight.NORMAL
        
        tabs_row.update()
        render_feed()

    def create_tab(text):
        is_selected = text == current_tab
        return ft.Container(
            content=ft.Text(
                text, 
                size=16, 
                color="#1565C0" if is_selected else "#9E9E9E",
                weight=ft.FontWeight.BOLD if is_selected else ft.FontWeight.NORMAL
            ),
            padding=ft.padding.symmetric(horizontal=12, vertical=8),
            on_click=on_tab_change,
            data=text  # Store tab name in data for easy access
        )

    tabs_row = ft.Row([
        create_tab("인수 인계"),
        ft.Text("|", size=16, color="#E0E0E0"), # Separator
        create_tab("발주 일지")
    ], alignment=ft.MainAxisAlignment.CENTER, spacing=10)

    # 입력 영역 - 마이크 버튼 + 텍스트 필드 + 전송 버튼
    input_area = ft.Container(
        content=ft.Column([
            voice_status,
            ft.Row([
                mic_btn,
                input_tf,
                ft.IconButton(ft.Icons.SEND_ROUNDED, on_click=lambda e: page.run_task(submit_entry))
            ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.END)
        ], spacing=5),
        padding=10
    )
    header = AppHeader(
        title_text="업무 일지",
        on_back_click=page.go_back
    )
    
    # Custom Header Container was combining title and tabs. 
    # Now AppHeader handles title. Tabs should be separate.

    async def poll_updates():
        while True:
            await asyncio.sleep(POLL_INTERVAL)
            # Only poll if this view is effectively active (simple check)
            try:
                await fetch_and_update()
            except Exception:
                break

    page.run_task(fetch_and_update)
    page.run_task(poll_updates)
    return [
        ft.SafeArea(
            expand=True,
            content=ft.Column([header, tabs_row, ft.Container(list_view, expand=True), input_area], expand=True)
        )
    ]
