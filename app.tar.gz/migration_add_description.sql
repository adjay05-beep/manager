ALTER TABLE calendar_events ADD COLUMN IF NOT EXISTS description TEXT;
